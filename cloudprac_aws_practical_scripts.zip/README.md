# CloudPrac AWS scripts (P02-P07)

Independent AWS CLI scripts for the AWS-based practicals in the provided syllabus photo:
- P02 Customer Data Management
- P03 Employee Attendance System
- P04 Online Billing System
- P05 Student Record Management
- P06 Employee Record Management
- P07 Library Management

P01 (virtualization) and P08 (CIA security model) are intentionally omitted.

## Requirements
AWS CLI v2, Python 3, and an AWS identity authorized for DynamoDB and S3 in the selected region. Default region is ap-south-1; override with AWS_REGION.

## Run
```bash
chmod +x run.sh practicals/*.sh
./run.sh P02
./run.sh P03
./run.sh P04
./run.sh P05
./run.sh P06
./run.sh P07
```
Each script asks before creating resources, writes a DynamoDB sample record, verifies it with GetItem, and for P02/P04/P05/P06/P07 uploads a sample file to a private S3 bucket. P03 is DynamoDB-only for attendance records.

## Cleanup
Each successful run prints a state-file path, for example:
```bash
./run.sh P05 cleanup "$HOME/.cloudprac-scripts/p05-RUN_ID.env"
```
Use the exact printed path. Keep the state file until cleanup succeeds.

## Important limitation
These are small CLI-based cloud-data demonstrations, not full web apps. The syllabus explicitly says P05-P07 use EC2 to host an application; these scripts cover DynamoDB and S3 but intentionally do not provision EC2 because the current CloudPrac EC2 public-IP workflow is failing. Do not claim EC2 hosting was demonstrated unless you separately deploy and verify it. AWS charges may apply; clean up promptly.
