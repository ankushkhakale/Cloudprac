#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
case "${1:-}" in
 P02) exec "$ROOT/practicals/P02_customer_data.sh" "${@:2}" ;;
 P03) exec "$ROOT/practicals/P03_employee_attendance.sh" "${@:2}" ;;
 P04) exec "$ROOT/practicals/P04_online_billing.sh" "${@:2}" ;;
 P05) exec "$ROOT/practicals/P05_student_records.sh" "${@:2}" ;;
 P06) exec "$ROOT/practicals/P06_employee_records.sh" "${@:2}" ;;
 P07) exec "$ROOT/practicals/P07_library_management.sh" "${@:2}" ;;
 *) echo "Usage: $0 {P02|P03|P04|P05|P06|P07} [cleanup /path/to/state.env]" >&2; exit 2 ;;
esac
