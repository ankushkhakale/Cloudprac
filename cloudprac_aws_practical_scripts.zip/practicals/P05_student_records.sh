#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PRACTICAL_ID=P05
EXPECTED_PRACTICAL_ID=P05
source "$ROOT/lib/common.sh"
need_aws
TABLE="$(safe_name "${PREFIX}-students")"
BUCKET=""
BUCKET="$(safe_name "${PREFIX}-student-docs")"
if [[ "${1:-}" == cleanup ]]; then
  load_state "$@"
  cleanup_table "${TABLE:-}"
  cleanup_bucket "${BUCKET:-}"
  exit 0
fi
confirm_create
aws dynamodb create-table --region "$REGION" --table-name "$TABLE" \
  --attribute-definitions AttributeName=student_id,AttributeType=S \
  --key-schema AttributeName=student_id,KeyType=HASH --billing-mode PAY_PER_REQUEST >/dev/null
wait_table "$TABLE"
aws dynamodb put-item --region "$REGION" --table-name "$TABLE" --item '{"student_id":{"S":"STU-001"},"name":{"S":"Ananya Patil"},"course":{"S":"Computer Engineering"},"year":{"N":"3"}}'
echo "=== Verify Student Record Management record ==="
aws dynamodb get-item --region "$REGION" --table-name "$TABLE" --key '{"student_id":{"S":"STU-001"}}' --output json
create_bucket "$BUCKET"
printf '%s\\n' 'Student ID: STU-001 | Ananya Patil | Computer Engineering' > "/tmp/P05-sample.txt"
aws s3 cp "/tmp/P05-sample.txt" "s3://$BUCKET/STU-001.txt" --sse AES256
echo "=== Verify private S3 document ==="
aws s3 ls "s3://$BUCKET/"
save_state
echo "SUCCESS: Student Record Management record verified."
