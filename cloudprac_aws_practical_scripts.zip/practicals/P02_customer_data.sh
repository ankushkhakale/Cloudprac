#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PRACTICAL_ID=P02
EXPECTED_PRACTICAL_ID=P02
source "$ROOT/lib/common.sh"
need_aws
TABLE="$(safe_name "${PREFIX}-customers")"
BUCKET=""
BUCKET="$(safe_name "${PREFIX}-customer-docs")"
if [[ "${1:-}" == cleanup ]]; then
  load_state "$@"
  cleanup_table "${TABLE:-}"
  cleanup_bucket "${BUCKET:-}"
  exit 0
fi
confirm_create
aws dynamodb create-table --region "$REGION" --table-name "$TABLE" \
  --attribute-definitions AttributeName=customer_id,AttributeType=S \
  --key-schema AttributeName=customer_id,KeyType=HASH --billing-mode PAY_PER_REQUEST >/dev/null
wait_table "$TABLE"
aws dynamodb put-item --region "$REGION" --table-name "$TABLE" --item '{"customer_id":{"S":"CUST-001"},"name":{"S":"Aarav Sharma"},"contact":{"S":"aarav@example.com"},"purchase":{"S":"Laptop bag"},"amount":{"N":"1299"}}'
echo "=== Verify Customer Data Management record ==="
aws dynamodb get-item --region "$REGION" --table-name "$TABLE" --key '{"customer_id":{"S":"CUST-001"}}' --output json
create_bucket "$BUCKET"
printf '%s\\n' 'Customer: CUST-001 | Aarav Sharma | Purchase: Laptop bag | INR 1299' > "/tmp/P02-sample.txt"
aws s3 cp "/tmp/P02-sample.txt" "s3://$BUCKET/customer.csv" --sse AES256
echo "=== Verify private S3 document ==="
aws s3 ls "s3://$BUCKET/"
save_state
echo "SUCCESS: Customer Data Management record verified."
