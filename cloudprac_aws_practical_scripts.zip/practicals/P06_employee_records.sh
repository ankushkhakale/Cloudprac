#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PRACTICAL_ID=P06
EXPECTED_PRACTICAL_ID=P06
source "$ROOT/lib/common.sh"
need_aws
TABLE="$(safe_name "${PREFIX}-employees")"
BUCKET=""
BUCKET="$(safe_name "${PREFIX}-employee-docs")"
if [[ "${1:-}" == cleanup ]]; then
  load_state "$@"
  cleanup_table "${TABLE:-}"
  cleanup_bucket "${BUCKET:-}"
  exit 0
fi
confirm_create
aws dynamodb create-table --region "$REGION" --table-name "$TABLE" \
  --attribute-definitions AttributeName=employee_id,AttributeType=S \
  --key-schema AttributeName=employee_id,KeyType=HASH --billing-mode PAY_PER_REQUEST >/dev/null
wait_table "$TABLE"
aws dynamodb put-item --region "$REGION" --table-name "$TABLE" --item '{"employee_id":{"S":"EMP-001"},"name":{"S":"Rohan Deshmukh"},"department":{"S":"IT"},"role":{"S":"Cloud Engineer"}}'
echo "=== Verify Employee Record Management record ==="
aws dynamodb get-item --region "$REGION" --table-name "$TABLE" --key '{"employee_id":{"S":"EMP-001"}}' --output json
create_bucket "$BUCKET"
printf '%s\\n' 'Employee ID: EMP-001 | Rohan Deshmukh | IT | Cloud Engineer' > "/tmp/P06-sample.txt"
aws s3 cp "/tmp/P06-sample.txt" "s3://$BUCKET/EMP-001.txt" --sse AES256
echo "=== Verify private S3 document ==="
aws s3 ls "s3://$BUCKET/"
save_state
echo "SUCCESS: Employee Record Management record verified."
