#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PRACTICAL_ID=P04
EXPECTED_PRACTICAL_ID=P04
source "$ROOT/lib/common.sh"
need_aws
TABLE="$(safe_name "${PREFIX}-billing")"
BUCKET=""
BUCKET="$(safe_name "${PREFIX}-invoices")"
if [[ "${1:-}" == cleanup ]]; then
  load_state "$@"
  cleanup_table "${TABLE:-}"
  cleanup_bucket "${BUCKET:-}"
  exit 0
fi
confirm_create
aws dynamodb create-table --region "$REGION" --table-name "$TABLE" \
  --attribute-definitions AttributeName=bill_id,AttributeType=S \
  --key-schema AttributeName=bill_id,KeyType=HASH --billing-mode PAY_PER_REQUEST >/dev/null
wait_table "$TABLE"
aws dynamodb put-item --region "$REGION" --table-name "$TABLE" --item '{"bill_id":{"S":"BILL-001"},"customer":{"S":"Aarav Sharma"},"item":{"S":"Cloud lab kit"},"quantity":{"N":"2"},"unit_price":{"N":"450"},"total":{"N":"900"},"status":{"S":"PAID"}}'
echo "=== Verify Online Billing System record ==="
aws dynamodb get-item --region "$REGION" --table-name "$TABLE" --key '{"bill_id":{"S":"BILL-001"}}' --output json
create_bucket "$BUCKET"
printf '%s\\n' 'Bill BILL-001 | Customer: Aarav Sharma | Total INR 900 | PAID' > "/tmp/P04-sample.txt"
aws s3 cp "/tmp/P04-sample.txt" "s3://$BUCKET/BILL-001.txt" --sse AES256
echo "=== Verify private S3 document ==="
aws s3 ls "s3://$BUCKET/"
save_state
echo "SUCCESS: Online Billing System record verified."
