#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PRACTICAL_ID=P07
EXPECTED_PRACTICAL_ID=P07
source "$ROOT/lib/common.sh"
need_aws
TABLE="$(safe_name "${PREFIX}-library")"
BUCKET=""
BUCKET="$(safe_name "${PREFIX}-book-files")"
if [[ "${1:-}" == cleanup ]]; then
  load_state "$@"
  cleanup_table "${TABLE:-}"
  cleanup_bucket "${BUCKET:-}"
  exit 0
fi
confirm_create
aws dynamodb create-table --region "$REGION" --table-name "$TABLE" \
  --attribute-definitions AttributeName=book_id,AttributeType=S \
  --key-schema AttributeName=book_id,KeyType=HASH --billing-mode PAY_PER_REQUEST >/dev/null
wait_table "$TABLE"
aws dynamodb put-item --region "$REGION" --table-name "$TABLE" --item '{"book_id":{"S":"BOOK-001"},"title":{"S":"Cloud Computing Basics"},"author":{"S":"A. Kumar"},"issued_to":{"S":"STU-001"},"issue_status":{"S":"ISSUED"}}'
echo "=== Verify Library Management record ==="
aws dynamodb get-item --region "$REGION" --table-name "$TABLE" --key '{"book_id":{"S":"BOOK-001"}}' --output json
create_bucket "$BUCKET"
printf '%s\\n' 'BOOK-001 | Cloud Computing Basics | Issued to STU-001' > "/tmp/P07-sample.txt"
aws s3 cp "/tmp/P07-sample.txt" "s3://$BUCKET/BOOK-001.txt" --sse AES256
echo "=== Verify private S3 document ==="
aws s3 ls "s3://$BUCKET/"
save_state
echo "SUCCESS: Library Management record verified."
