#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PRACTICAL_ID=P03
EXPECTED_PRACTICAL_ID=P03
source "$ROOT/lib/common.sh"
need_aws
TABLE="$(safe_name "${PREFIX}-attendance")"
BUCKET=""
if [[ "${1:-}" == cleanup ]]; then
  load_state "$@"
  cleanup_table "${TABLE:-}"
  cleanup_bucket "${BUCKET:-}"
  exit 0
fi
confirm_create
aws dynamodb create-table --region "$REGION" --table-name "$TABLE" \
  --attribute-definitions AttributeName=employee_id,AttributeType=S AttributeName=attendance_date,AttributeType=S \
  --key-schema AttributeName=employee_id,KeyType=HASH AttributeName=attendance_date,KeyType=RANGE --billing-mode PAY_PER_REQUEST >/dev/null
wait_table "$TABLE"
aws dynamodb put-item --region "$REGION" --table-name "$TABLE" --item '{"employee_id":{"S":"EMP-001"},"attendance_date":{"S":"2026-10-11"},"status":{"S":"Present"},"check_in":{"S":"09:02"}}'
echo "=== Verify Employee Attendance System record ==="
aws dynamodb get-item --region "$REGION" --table-name "$TABLE" --key '{"employee_id":{"S":"EMP-001"},"attendance_date":{"S":"2026-10-11"}}' --output json
save_state
echo "SUCCESS: Employee Attendance System record verified."
