#!/usr/bin/env bash
# CloudPrac P05 — Student Record Management (EC2 + S3 + DynamoDB)
# Creates a small HTTP application on EC2, DynamoDB student table, private S3 bucket,
# least-privilege EC2 role, and restricted port-5000 ingress. Includes cleanup.
set -Eeuo pipefail
umask 077

PRACTICAL_ID="P05"
REGION="${AWS_REGION:-${AWS_DEFAULT_REGION:-ap-south-1}}"
RUN_ID="${RUN_ID:-$(date -u +%Y%m%d-%H%M%S)-$(od -An -N3 -tx1 /dev/urandom | tr -d ' \n')}"
PREFIX="cloudprac-p05-$(printf '%s' "$RUN_ID" | tr '[:upper:]' '[:lower:]')"
STATE_DIR="${CLOUDPRAC_STATE_DIR:-$HOME/.cloudprac-scripts}"
STATE_FILE="$STATE_DIR/${RUN_ID}.env"
APP_PORT=5000
WAIT_SECONDS="${WAIT_SECONDS:-420}"

log() { printf '\n[%s] %s\n' "$(date -u +%H:%M:%S)" "$*"; }
die() { echo "ERROR: $*" >&2; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || die "Required command missing: $1"; }
awsx() { aws --region "$REGION" "$@"; }
retry() {
  local attempts="$1"; shift
  local n=1
  until "$@"; do
    if (( n >= attempts )); then return 1; fi
    sleep "$(( n < 5 ? n : 5 ))"
    n=$((n+1))
  done
}
save_state() {
  mkdir -p "$STATE_DIR"; chmod 700 "$STATE_DIR"
  cat > "$STATE_FILE" <<EOF
REGION=$(printf '%q' "$REGION")
RUN_ID=$(printf '%q' "$RUN_ID")
PREFIX=$(printf '%q' "$PREFIX")
ACCOUNT_ID=$(printf '%q' "$ACCOUNT_ID")
TABLE_NAME=$(printf '%q' "${TABLE_NAME:-}")
BUCKET_NAME=$(printf '%q' "${BUCKET_NAME:-}")
ROLE_NAME=$(printf '%q' "${ROLE_NAME:-}")
PROFILE_NAME=$(printf '%q' "${PROFILE_NAME:-}")
SG_ID=$(printf '%q' "${SG_ID:-}")
INSTANCE_ID=$(printf '%q' "${INSTANCE_ID:-}")
EOF
  chmod 600 "$STATE_FILE"
  log "State saved: $STATE_FILE"
}
confirm() {
  echo "P05 Student Record Management"
  echo "Region: $REGION | Run ID: $RUN_ID"
  echo "Creates billable AWS resources: EC2, EBS/public IPv4, S3, DynamoDB. IAM/security groups are also created."
  echo "Application ingress is restricted to your current public IP (/32)."
  read -r -p "Provision the complete P05 stack? [y/N] " ans
  [[ "$ans" == "y" || "$ans" == "Y" ]] || { echo "Cancelled; no resources created."; exit 0; }
}
load_state() {
  local file="${2:-}"
  [[ -n "$file" && -f "$file" ]] || die "Usage: $0 cleanup /path/to/state.env"
  # Only source a state file produced by this script and stored with mode 600.
  # shellcheck disable=SC1090
  source "$file"
  [[ "${REGION:-}" && "${PREFIX:-}" == cloudprac-p05-* ]] || die "Invalid P05 state file."
  [[ "${ACCOUNT_ID:-}" == "$CURRENT_ACCOUNT" ]] || die "State belongs to a different AWS account; refusing cleanup."
}
region_bucket_create() {
  if [[ "$REGION" == "us-east-1" ]]; then
    aws s3api create-bucket --region "$REGION" --bucket "$BUCKET_NAME" >/dev/null
  else
    aws s3api create-bucket --region "$REGION" --bucket "$BUCKET_NAME" \
      --create-bucket-configuration "LocationConstraint=$REGION" >/dev/null
  fi
}
pick_public_subnet() {
  # Require a subnet that auto-assigns public IPv4 and has an effective IGW route.
  local subnet_json
  subnet_json="$(awsx ec2 describe-subnets --filters "Name=state,Values=available" --output json)"
  local route_json
  route_json="$(awsx ec2 describe-route-tables --output json)"
  local igw_json
  igw_json="$(awsx ec2 describe-internet-gateways --output json)"
  python3 - "$subnet_json" "$route_json" "$igw_json" <<'PY'
import json,sys
subnets=json.loads(sys.argv[1]).get("Subnets",[])
routes=json.loads(sys.argv[2]).get("RouteTables",[])
igws=json.loads(sys.argv[3]).get("InternetGateways",[])
attached={g["InternetGatewayId"] for g in igws if any(a.get("State")=="available" for a in g.get("Attachments",[]))}
explicit={}
main={}
for rt in routes:
    for a in rt.get("Associations",[]):
        if a.get("SubnetId"): explicit[a["SubnetId"]]=rt
        if a.get("Main"): main[rt.get("VpcId")]=rt
for s in subnets:
    if not s.get("MapPublicIpOnLaunch"): continue
    rt=explicit.get(s["SubnetId"], main.get(s["VpcId"],{}))
    ok=any(r.get("DestinationCidrBlock")=="0.0.0.0/0" and r.get("GatewayId") in attached and r.get("State","active")=="active" for r in rt.get("Routes",[]))
    if ok:
        print(s["SubnetId"]); sys.exit(0)
sys.exit(1)
PY
}
make_user_data() {
  cat <<'USERDATA'
#!/bin/bash
set -euxo pipefail
dnf install -y python3 python3-pip
python3 -m pip install --upgrade boto3
mkdir -p /opt/cloudprac-p05
cat > /opt/cloudprac-p05/app.py <<'PYAPP'
import json, os, base64, re
from http.server import BaseHTTPRequestHandler, HTTPServer
import boto3
REGION=os.environ.get("AWS_REGION","ap-south-1")
TABLE=os.environ["TABLE_NAME"]
BUCKET=os.environ["BUCKET_NAME"]
ddb=boto3.resource("dynamodb",region_name=REGION).Table(TABLE)
s3=boto3.client("s3",region_name=REGION)
def response(handler, code, payload):
    body=json.dumps(payload,indent=2).encode()
    handler.send_response(code); handler.send_header("Content-Type","application/json")
    handler.send_header("Content-Length",str(len(body))); handler.end_headers(); handler.wfile.write(body)
class Handler(BaseHTTPRequestHandler):
    def log_message(self,fmt,*args): print("%s - %s"%(self.address_string(),fmt%args),flush=True)
    def do_GET(self):
        if self.path=="/health":
            return response(self,200,{"status":"ok","service":"cloudprac-p05","region":REGION})
        if self.path in ("/","/students"):
            rows=ddb.scan().get("Items",[])
            return response(self,200,{"application":"CloudPrac P05 Student Records","region":REGION,
                "endpoints":{"GET /students":"list student records","POST /students":"create/update student",
                "POST /documents":"upload document using JSON {key,content_base64}","GET /documents":"list documents"},
                "students":rows})
        if self.path=="/documents":
            items=s3.list_objects_v2(Bucket=BUCKET).get("Contents",[])
            return response(self,200,{"documents":[{"key":x["Key"],"size":x["Size"]} for x in items]})
        return response(self,404,{"error":"not found"})
    def do_POST(self):
        try:
            n=int(self.headers.get("Content-Length","0"))
            if n>1_000_000: return response(self,413,{"error":"request too large"})
            data=json.loads(self.rfile.read(n) or b"{}")
            if self.path=="/students":
                sid=str(data.get("student_id","")).strip()
                name=str(data.get("name","")).strip()
                course=str(data.get("course","")).strip()
                year=str(data.get("year","")).strip()
                if not sid or not name or not course: return response(self,400,{"error":"student_id, name and course are required"})
                ddb.put_item(Item={"student_id":sid,"name":name,"course":course,"year":year})
                return response(self,201,{"message":"student saved","student_id":sid})
            if self.path=="/documents":
                key=str(data.get("key","")).strip()
                encoded=data.get("content_base64","")
                if not key or ".." in key or key.startswith("/"): return response(self,400,{"error":"invalid key"})
                raw=base64.b64decode(encoded,validate=True)
                if len(raw)>500_000: return response(self,413,{"error":"document too large"})
                s3.put_object(Bucket=BUCKET,Key=key,Body=raw,ServerSideEncryption="AES256")
                return response(self,201,{"message":"document uploaded","key":key,"bytes":len(raw)})
            return response(self,404,{"error":"not found"})
        except Exception as e:
            return response(self,400,{"error":str(e)})
HTTPServer(("0.0.0.0",5000),Handler).serve_forever()
PYAPP
cat > /etc/systemd/system/cloudprac-p05.service <<'UNIT'
[Unit]
Description=CloudPrac P05 Student Records Demo
After=network-online.target
Wants=network-online.target
[Service]
Environment=AWS_REGION=__REGION__
Environment=TABLE_NAME=__TABLE__
Environment=BUCKET_NAME=__BUCKET__
WorkingDirectory=/opt/cloudprac-p05
ExecStart=/usr/bin/python3 /opt/cloudprac-p05/app.py
Restart=always
RestartSec=3
User=root
[Install]
WantedBy=multi-user.target
UNIT
sed -i 's|__REGION__|REGION_TOKEN|; s|__TABLE__|TABLE_TOKEN|; s|__BUCKET__|BUCKET_TOKEN|' /etc/systemd/system/cloudprac-p05.service
systemctl daemon-reload
systemctl enable --now cloudprac-p05
USERDATA
}
# --- cleanup path ---
if [[ "${1:-}" == "cleanup" ]]; then
  need aws; need python3
  IDENTITY="$(aws sts get-caller-identity --output json)"
  CURRENT_ACCOUNT="$(python3 -c 'import json,sys;print(json.load(sys.stdin)["Account"])' <<<"$IDENTITY")"
  load_state "$@"
  log "Cleaning P05 run $RUN_ID in $REGION (account $ACCOUNT_ID)"
  if [[ -n "${INSTANCE_ID:-}" ]]; then
    if awsx ec2 describe-instances --instance-ids "$INSTANCE_ID" >/dev/null 2>&1; then
      awsx ec2 terminate-instances --instance-ids "$INSTANCE_ID" >/dev/null || true
      awsx ec2 wait instance-terminated --instance-ids "$INSTANCE_ID" || echo "WARNING: instance termination wait failed: $INSTANCE_ID"
      echo "EC2 termination requested/verified: $INSTANCE_ID"
    else echo "EC2 instance already absent: $INSTANCE_ID"; fi
  fi
  if [[ -n "${SG_ID:-}" ]]; then
    if awsx ec2 describe-security-groups --group-ids "$SG_ID" >/dev/null 2>&1; then
      retry 5 awsx ec2 delete-security-group --group-id "$SG_ID" && echo "Deleted security group $SG_ID" || echo "WARNING: could not delete SG $SG_ID (check dependencies)"
    fi
  fi
  if [[ -n "${TABLE_NAME:-}" ]] && awsx dynamodb describe-table --table-name "$TABLE_NAME" >/dev/null 2>&1; then
    awsx dynamodb delete-table --table-name "$TABLE_NAME" >/dev/null
    awsx dynamodb wait table-not-exists --table-name "$TABLE_NAME"
    echo "Deleted DynamoDB table $TABLE_NAME"
  else echo "DynamoDB table absent: ${TABLE_NAME:-}"; fi
  if [[ -n "${BUCKET_NAME:-}" ]] && aws s3api head-bucket --bucket "$BUCKET_NAME" >/dev/null 2>&1; then
    # This demo does not enable bucket versioning; recursively remove its objects.
    aws s3 rm "s3://$BUCKET_NAME" --recursive >/dev/null
    aws s3 rb "s3://$BUCKET_NAME" >/dev/null
    echo "Deleted S3 bucket $BUCKET_NAME"
  else echo "S3 bucket absent/unavailable: ${BUCKET_NAME:-}"; fi
  if [[ -n "${PROFILE_NAME:-}" ]]; then
    awsx iam remove-role-from-instance-profile --instance-profile-name "$PROFILE_NAME" --role-name "$ROLE_NAME" >/dev/null 2>&1 || true
    awsx iam delete-instance-profile --instance-profile-name "$PROFILE_NAME" >/dev/null 2>&1 || true
    echo "Instance profile cleanup attempted: $PROFILE_NAME"
  fi
  if [[ -n "${ROLE_NAME:-}" ]]; then
    awsx iam delete-role-policy --role-name "$ROLE_NAME" --policy-name "${ROLE_NAME}-policy" >/dev/null 2>&1 || true
    awsx iam delete-role --role-name "$ROLE_NAME" >/dev/null 2>&1 || true
    echo "IAM role cleanup attempted: $ROLE_NAME"
  fi
  echo "Cleanup pass finished. Verify the resources are absent in the AWS console/CLI."
  exit 0
fi

need aws; need python3; need curl; need base64
IDENTITY="$(aws sts get-caller-identity --output json)"
ACCOUNT_ID="$(python3 -c 'import json,sys;print(json.load(sys.stdin)["Account"])' <<<"$IDENTITY")"
mkdir -p "$STATE_DIR"; chmod 700 "$STATE_DIR"
confirm
TABLE_NAME="${PREFIX}-students"
BUCKET_NAME="${PREFIX}-docs"
ROLE_NAME="${PREFIX}-ec2-role"
PROFILE_NAME="${PREFIX}-profile"
SG_ID=""
INSTANCE_ID=""

# Detect current public IPv4 for restricted app ingress.
MY_IP="${APP_CIDR:-}"
if [[ -z "$MY_IP" ]]; then
  MY_IP="$(curl -4fsS --max-time 8 https://checkip.amazonaws.com | tr -d '[:space:]')/32" || die "Could not detect public IPv4. Rerun with APP_CIDR=x.x.x.x/32"
fi
[[ "$MY_IP" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}/32$ ]] || die "APP_CIDR must be an IPv4 /32, got $MY_IP"
log "Account: $ACCOUNT_ID | Region: $REGION | Restricted app CIDR: $MY_IP"
save_state

# Create DynamoDB table.
log "Creating DynamoDB table $TABLE_NAME"
awsx dynamodb create-table --table-name "$TABLE_NAME" \
  --attribute-definitions AttributeName=student_id,AttributeType=S \
  --key-schema AttributeName=student_id,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST >/dev/null
awsx dynamodb wait table-exists --table-name "$TABLE_NAME"

# Create private S3 bucket.
log "Creating private S3 bucket $BUCKET_NAME"
region_bucket_create
aws s3api put-public-access-block --bucket "$BUCKET_NAME" \
  --public-access-block-configuration BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true
aws s3api put-bucket-encryption --bucket "$BUCKET_NAME" --server-side-encryption-configuration '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"AES256"}}]}'

# IAM role for EC2 with only access to this table and bucket.
log "Creating least-privilege EC2 role and instance profile"
cat > /tmp/"${ROLE_NAME}-trust.json" <<'TRUST'
{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"ec2.amazonaws.com"},"Action":"sts:AssumeRole"}]}
TRUST
awsx iam create-role --role-name "$ROLE_NAME" --assume-role-policy-document file:///tmp/"${ROLE_NAME}-trust.json" \
  --description "CloudPrac P05 EC2 application role ${RUN_ID}" >/dev/null
cat > /tmp/"${ROLE_NAME}-policy.json" <<POLICY
{"Version":"2012-10-17","Statement":[
{"Effect":"Allow","Action":["dynamodb:PutItem","dynamodb:GetItem","dynamodb:Scan"],"Resource":"arn:aws:dynamodb:${REGION}:${ACCOUNT_ID}:table/${TABLE_NAME}"},
{"Effect":"Allow","Action":["s3:PutObject","s3:GetObject","s3:ListBucket"],"Resource":["arn:aws:s3:::${BUCKET_NAME}","arn:aws:s3:::${BUCKET_NAME}/*"]}
]}
POLICY
awsx iam put-role-policy --role-name "$ROLE_NAME" --policy-name "${ROLE_NAME}-policy" --policy-document file:///tmp/"${ROLE_NAME}-policy.json"
awsx iam create-instance-profile --instance-profile-name "$PROFILE_NAME" >/dev/null
awsx iam add-role-to-instance-profile --instance-profile-name "$PROFILE_NAME" --role-name "$ROLE_NAME"
sleep 10

# Pick a subnet that really has an Internet Gateway route.
log "Selecting a public subnet with an active Internet Gateway route"
SUBNET_ID="$(pick_public_subnet)" || die "No eligible public subnet found. No EC2 instance was launched; check VPC route tables/Internet Gateway. Existing resources are recorded in $STATE_FILE"
VPC_ID="$(awsx ec2 describe-subnets --subnet-ids "$SUBNET_ID" --query 'Subnets[0].VpcId' --output text)"
log "Using subnet $SUBNET_ID in VPC $VPC_ID"

SG_ID="$(awsx ec2 create-security-group --group-name "${PREFIX}-sg" --description "CloudPrac P05 app ingress from ${MY_IP}" --vpc-id "$VPC_ID" --query GroupId --output text)"
awsx ec2 authorize-security-group-ingress --group-id "$SG_ID" --protocol tcp --port "$APP_PORT" --cidr "$MY_IP" >/dev/null
save_state

# Resolve current Amazon Linux 2023 AMI via AWS's public SSM parameter.
AMI_ID="$(awsx ssm get-parameter --name /aws/service/ami-amazon-linux-latest/al2023-ami-kernel-default-x86_64 --query Parameter.Value --output text)"
[[ "$AMI_ID" == ami-* ]] || die "Could not resolve Amazon Linux 2023 AMI: $AMI_ID"

# Inject run-specific configuration into user-data.
USER_DATA="$(make_user_data)"
USER_DATA="${USER_DATA//REGION_TOKEN/$REGION}"
USER_DATA="${USER_DATA//TABLE_TOKEN/$TABLE_NAME}"
USER_DATA="${USER_DATA//BUCKET_TOKEN/$BUCKET_NAME}"
printf '%s' "$USER_DATA" > /tmp/"${PREFIX}-user-data.sh"

log "Launching EC2 instance (t3.micro) with public IPv4 and app-only ingress"
RUN_RESPONSE="$(awsx ec2 run-instances \
  --image-id "$AMI_ID" --instance-type t3.micro --min-count 1 --max-count 1 \
  --iam-instance-profile "Name=$PROFILE_NAME" \
  --network-interfaces "DeviceIndex=0,SubnetId=$SUBNET_ID,Groups=$SG_ID,AssociatePublicIpAddress=true,DeleteOnTermination=true" \
  --tag-specifications "ResourceType=instance,Tags=[{Key=Name,Value=${PREFIX}-app},{Key=Project,Value=CloudPrac},{Key=Practical,Value=P05},{Key=RunId,Value=${RUN_ID}}]" \
  --block-device-mappings '[{"DeviceName":"/dev/xvda","Ebs":{"VolumeSize":8,"VolumeType":"gp3","DeleteOnTermination":true}}]' \
  --user-data "file:///tmp/${PREFIX}-user-data.sh" --output json)"
INSTANCE_ID="$(python3 -c 'import json,sys;print(json.load(sys.stdin)["Instances"][0]["InstanceId"])' <<<"$RUN_RESPONSE")"
[[ "$INSTANCE_ID" == i-* ]] || die "RunInstances did not return a valid instance ID."
save_state
log "EC2 instance launched: $INSTANCE_ID"

deadline=$((SECONDS + WAIT_SECONDS))
PUBLIC_IP=""
while (( SECONDS < deadline )); do
  if desc="$(awsx ec2 describe-instances --instance-ids "$INSTANCE_ID" --output json 2>/dev/null)"; then
    values="$(python3 -c 'import json,sys; d=json.load(sys.stdin); i=(d.get("Reservations") or [{}])[0].get("Instances") or [{}]; x=i[0]; n=x.get("NetworkInterfaces") or [{}]; print(x.get("State",{}).get("Name",""), x.get("PublicIpAddress") or (n[0].get("Association") or {}).get("PublicIp",""))' <<<"$desc" 2>/dev/null || true)"
    state="${values%% *}"; ip="${values#* }"
    if [[ "$state" == "running" && "$ip" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then PUBLIC_IP="$ip"; break; fi
    [[ "$state" == "terminated" ]] && die "EC2 instance terminated during boot. Inspect EC2 system log and state file $STATE_FILE"
  fi
  sleep 5
done
[[ -n "$PUBLIC_IP" ]] || die "No public IPv4 observed after ${WAIT_SECONDS}s. State file: $STATE_FILE. Do not rerun; inspect/cleanup this run."
log "EC2 public IPv4 assigned: $PUBLIC_IP"
log "Waiting for application bootstrap and health endpoint"
HEALTH_OK=""
while (( SECONDS < deadline )); do
  if curl -fsS --connect-timeout 3 --max-time 5 "http://${PUBLIC_IP}:${APP_PORT}/health" >/tmp/"${PREFIX}-health.json"; then HEALTH_OK=1; break; fi
  sleep 5
done
[[ "$HEALTH_OK" == 1 ]] || die "EC2 has public IP $PUBLIC_IP but app health check did not pass. Inspect user-data/cloud-init and clean using $STATE_FILE"

log "Creating and verifying a sample student through the hosted application"
curl -fsS --max-time 15 -X POST "http://${PUBLIC_IP}:${APP_PORT}/students" \
  -H 'Content-Type: application/json' \
  -d '{"student_id":"STU-001","name":"Ananya Patil","course":"Computer Engineering","year":"3"}'
echo
curl -fsS --max-time 15 "http://${PUBLIC_IP}:${APP_PORT}/students"
echo
printf 'Student ID: STU-001\nName: Ananya Patil\nCourse: Computer Engineering\n' >/tmp/"${PREFIX}-student.txt"
ENCODED="$(base64 -w0 /tmp/"${PREFIX}-student.txt")"
curl -fsS --max-time 15 -X POST "http://${PUBLIC_IP}:${APP_PORT}/documents" \
  -H 'Content-Type: application/json' \
  -d "{\"key\":\"STU-001.txt\",\"content_base64\":\"${ENCODED}\"}"
echo
curl -fsS --max-time 15 "http://${PUBLIC_IP}:${APP_PORT}/documents"
echo

log "SUCCESS: P05 end-to-end checks passed."
echo "Application URL: http://${PUBLIC_IP}:${APP_PORT}/"
echo "Health URL:      http://${PUBLIC_IP}:${APP_PORT}/health"
echo "DynamoDB table:  $TABLE_NAME"
echo "S3 bucket:       $BUCKET_NAME"
echo "EC2 instance:    $INSTANCE_ID"
echo "AWS region:      $REGION"
echo "Run state:       $STATE_FILE"
echo
echo "Cleanup command (run after demonstration):"
echo "  $0 cleanup \"$STATE_FILE\""
echo
echo "Security note: application ingress is restricted to $MY_IP. The demo uses plain HTTP for a classroom lab; do not expose it publicly or use real sensitive student data."
