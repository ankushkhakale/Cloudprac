# P05 Complete AWS Practical — EC2 + S3 + DynamoDB

This is a standalone, end-to-end implementation of the exact P05 syllabus requirement:
- DynamoDB stores student records.
- S3 stores student documents in a private, AES256-encrypted bucket.
- EC2 hosts a small HTTP application with health, student-record, and document endpoints.
- An EC2 instance profile grants least-privilege access to the one table and one bucket.
- Inbound port 5000 is restricted to the detected public IP (/32), or `APP_CIDR=x.x.x.x/32`.
- A state file is saved as resources are created so cleanup can find the stack.

## Run in AWS CloudShell
```bash
chmod +x P05_complete.sh
AWS_REGION=ap-south-1 ./P05_complete.sh
```
Review the confirmation prompt. This creates real AWS resources and may incur charges.

## Cleanup
The script prints a state file and cleanup command after provisioning. Use the exact path:
```bash
./P05_complete.sh cleanup "$HOME/.cloudprac-scripts/RUN_ID.env"
```
Cleanup terminates the instance, removes the security group, deletes the DynamoDB table and S3 bucket, and attempts to remove the instance profile and IAM role. Verify all resources are gone in AWS.

## Notes
- Requires AWS CLI v2, Python 3, curl, and permissions for EC2, IAM, S3, DynamoDB, and SSM.
- Chooses a subnet only if it has public IPv4 auto-assignment and an active route to an attached Internet Gateway.
- Uses Amazon Linux 2023 and installs boto3 at boot; instance bootstrap needs outbound internet access.
- The application is plain HTTP for a classroom demo. Do not put real sensitive records into it.
- EC2, EBS, public IPv4, S3, and DynamoDB charges may apply. Clean up promptly.
- If provisioning fails partway, use the state file path printed in the error/log where possible; inspect and clean partial resources before retrying.
